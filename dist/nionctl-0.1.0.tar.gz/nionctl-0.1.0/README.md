# nionctl

An abbreviation of common linux utilities into a single cli